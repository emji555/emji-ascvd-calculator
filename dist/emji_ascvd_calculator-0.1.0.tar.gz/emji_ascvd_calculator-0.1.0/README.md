# ASCVD Calculator

This package provides an extended ASCVD risk calculation formula for predicting cardiovascular disease (CVD) risk.

## Installation

```bash
pip install emji_ascvd_calculator
